package com.example.library;

import com.example.library.dao.BookDao;
import com.example.library.dao.RecordDao;
import com.example.library.pojo.Book;
import com.example.library.pojo.Record;
import com.example.library.service.LibraryService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LibraryServiceTest {

    @Autowired
    private BookDao bookDao;

    @Autowired
    private RecordDao recordDao;

    @Autowired
    private LibraryService libraryService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @BeforeAll
    static void printSuiteHeader() {
        System.out.println();
        System.out.println("============================================================");
        System.out.println(" Library Borrowing Management System - Integration Test Run ");
        System.out.println("============================================================");
    }

    @BeforeEach
    void setUp(TestInfo testInfo) {
        printSeparator();
        System.out.println("Running: " + testInfo.getDisplayName());
        jdbcTemplate.update("DELETE FROM record");
        jdbcTemplate.update("DELETE FROM book");
        bookDao.addBook(new Book("Spring in Action", 2));
        System.out.println("Setup  : reset tables and inserted book 'Spring in Action' with stock = 2");
    }

    @Test
    @Order(1)
    @DisplayName("Test successful borrowing")
    void testSuccessfulBorrowing() {
        System.out.println("Action : borrowBook(\"Spring in Action\", \"Abdul\")");
        libraryService.borrowBook("Spring in Action", "Abdul");

        Book book = bookDao.findBookByName("Spring in Action");
        System.out.println("Check  : current stock = " + book.getStock());
        assertEquals(1, book.getStock());

        List<Record> records = recordDao.findAllRecords();
        boolean recordExists = records.stream().anyMatch(r -> r.getBookName().equals("Spring in Action")
                && r.getBorrower().equals("Abdul")
                && r.getStatus().equals("BORROWED"));
        System.out.println("Check  : borrowing record inserted = " + recordExists);
        assertTrue(recordExists);
        System.out.println("Result : PASS");
    }

    @Test
    @Order(2)
    @DisplayName("Test insufficient stock (should trigger rollback)")
    void testInsufficientStockShouldRollback() {
        System.out.println("Action : set stock to 0 and try borrowBook(\"Spring in Action\", \"Ali\")");
        Book book = bookDao.findBookByName("Spring in Action");
        bookDao.updateStock(book.getId(), 0);

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> libraryService.borrowBook("Spring in Action", "Ali"));

        System.out.println("Check  : exception message = " + ex.getMessage());
        assertEquals("Insufficient stock", ex.getMessage());

        Book updated = bookDao.findBookByName("Spring in Action");
        System.out.println("Check  : stock after rollback = " + updated.getStock());
        assertEquals(0, updated.getStock());

        List<Record> records = recordDao.findAllRecords();
        boolean rollbackWorked = records.stream().noneMatch(r -> r.getBookName().equals("Spring in Action")
                && r.getBorrower().equals("Ali"));
        System.out.println("Check  : no borrow record inserted = " + rollbackWorked);
        assertTrue(rollbackWorked);
        System.out.println("Result : PASS");
    }

    @Test
    @Order(3)
    @DisplayName("Test returning operation")
    void testReturningOperation() {
        System.out.println("Action : borrow then return book for borrower 'Sara'");
        libraryService.borrowBook("Spring in Action", "Sara");
        libraryService.returnBook("Spring in Action", "Sara");

        Book book = bookDao.findBookByName("Spring in Action");
        System.out.println("Check  : current stock = " + book.getStock());
        assertEquals(2, book.getStock());

        List<Record> records = recordDao.findAllRecords();
        boolean returned = records.stream().anyMatch(r -> r.getBookName().equals("Spring in Action")
                && r.getBorrower().equals("Sara")
                && r.getStatus().equals("RETURNED"));
        System.out.println("Check  : return record updated = " + returned);
        assertTrue(returned);
        System.out.println("Result : PASS");
    }

    @AfterAll
    static void printSuiteFooter() {
        printSeparator();
        System.out.println("Test suite finished.");
        printSeparator();
    }

    private static void printSeparator() {
        System.out.println("------------------------------------------------------------");
    }
}
